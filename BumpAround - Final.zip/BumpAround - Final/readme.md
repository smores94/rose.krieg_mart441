# rose.krieg_mart441


Added 3 levels

6)Mirror World
7)Glitch World
8)Eclipse (not really fully fleshed out)

had a really cool shield effect "bonus" for the additional levels but had a lot of difficulty getting it to work in each level correctly and finally decided that for now it had to go. 

Phases 3-8 have "Danger Spawn" which will subtract when you touch them!

And don't forget, when you "bump" into obstacles, it also subtracts from your score, so be
careful when you "Bump Around"!
