# rose.krieg_mart441

I did about 300 revisions on this, mostly related to trying to get a reset button to function (which did not happen), and a "you won". Neither ended up working and to be honest, even after running the whole thing through AI, still could not get it to function correctly. Getting some mad respect for game developers these days. 

The actual assigned portion of this assignment went pretty well. The biggest challenge I think I had with that was getting the game to subtract points for bouncing into the objects. I was so impressed with that, I thought the reset button would be no problem, as I've done it before, I'm still bothered by it! 
